import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login_page.dart'; // Import halaman login

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _searchController = TextEditingController();

  // Fungsi untuk mengupdate status isComplete
  void _toggleComplete(String todoId, bool currentStatus) {
    _firestore.collection('Todos').doc(todoId).update({
      'isComplete': !currentStatus,  // Membalik status isComplete
    });
  }

  // Fungsi untuk menampilkan dialog tambah todo baru
  void _showAddTodoDialog() {
    showDialog(
      context: context,
      builder: (context) {
        final TextEditingController titleController = TextEditingController();
        final TextEditingController descriptionController = TextEditingController();

        return AlertDialog(
          title: Text('Tambah Todo Baru'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: InputDecoration(labelText: 'Judul'),
              ),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(labelText: 'Deskripsi'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                String title = titleController.text;
                String description = descriptionController.text;

                if (title.isNotEmpty && description.isNotEmpty) {
                  // Menambahkan todo ke Firestore
                  _firestore.collection('Todos').add({
                    'title': title,  // Ganti 'tittle' menjadi 'title'
                    'description': description,
                    'isComplete': false,
                    'uid': 'userUid', // Gantilah dengan UID pengguna yang sudah login
                  });
                  Navigator.pop(context); // Menutup dialog setelah menambahkan todo
                }
              },
              child: Text('Tambah'),
            ),
          ],
        );
      },
    );
  }

  // Fungsi untuk logout dan kembali ke halaman login
  void _logout() async {
    try {
      await FirebaseAuth.instance.signOut();  // Logout dari Firebase
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),  // Arahkan ke halaman login
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Logout gagal: ${e.toString()}'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.logout),
          onPressed: _logout, // Tombol logout
        ),
        title: Text('ToDo List'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: _showAddTodoDialog, // Memanggil fungsi untuk menampilkan dialog
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Cari Todo',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          // Daftar Todo
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _firestore.collection('Todos').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text('Tidak ada data.'));
                }

                final todos = snapshot.data!.docs
                    .where((todo) => todo['title']  // Ganti 'tittle' menjadi 'title'
                    .toString()
                    .toLowerCase()
                    .contains(_searchController.text.toLowerCase())) // Filter berdasarkan pencarian
                    .toList();

                return ListView.builder(
                  itemCount: todos.length,
                  itemBuilder: (context, index) {
                    final todo = todos[index];
                    final title = todo['title'] ?? 'Tidak ada judul';
                    final description = todo['description'] ?? 'Tidak ada deskripsi';
                    final isComplete = todo['isComplete'] ?? false;
                    final todoId = todo.id;

                    return ListTile(
                      title: Text(title),
                      subtitle: Text(description),
                      leading: IconButton(
                        icon: Icon(
                          isComplete
                              ? Icons.check_box
                              : Icons.check_box_outline_blank,
                        ),
                        onPressed: () => _toggleComplete(todoId, isComplete),
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          _firestore.collection('Todos').doc(todoId).delete();
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
