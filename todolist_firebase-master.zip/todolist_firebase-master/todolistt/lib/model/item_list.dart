import 'todo.dart';

class ItemList {
  final List<Todo> todos;

  ItemList({required this.todos});

  void addItem(Todo item) {
    todos.add(item);
  }

  void removeItem(String id) {
    todos.removeWhere((todo) => todo.id == id);
  }

  List<Todo> getCompletedTodos() {
    return todos.where((todo) => todo.isCompleted).toList();
  }

  List<Todo> getPendingTodos() {
    return todos.where((todo) => !todo.isCompleted).toList();
  }
}
