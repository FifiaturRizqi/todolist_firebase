class Todo {
  final String id;
  final String title;
  final bool isCompleted;

  Todo({
    required this.id,
    required this.title,
    this.isCompleted = false,
  });

  // Menyimpan data sebagai map untuk Firebase
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'isCompleted': isCompleted,
    };
  }

  // Membaca data dari map (misalnya saat mengambil dari Firebase)
  factory Todo.fromMap(Map<String, dynamic> map, String id) {
    return Todo(
      id: id,
      title: map['title'],
      isCompleted: map['isCompleted'] ?? false,
    );
  }
}
