import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TodoService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Menambahkan todo baru ke Firestore
  Future<void> addTodo(String title, String description) async {
    try {
      String uid = _auth.currentUser!.uid;

      // Menambahkan todo ke koleksi 'Todos'
      await _firestore.collection('Todos').add({
        'title': title,
        'description': description,
        'isComplete': false,  // Status awal adalah false
        'uid': uid,           // Menyimpan UID pengguna yang membuat todo
      });

      print("Todo added successfully!");
    } catch (e) {
      print("Failed to add todo: $e");
    }
  }
}
