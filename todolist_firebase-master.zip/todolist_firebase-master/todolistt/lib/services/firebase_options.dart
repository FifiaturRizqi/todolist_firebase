import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return FirebaseOptions(
      apiKey: 'AIzaSyCOfwRUJh1P6uDxlNywJ2lrohRK6CFYvC4',
      appId: '1:611007448413:android:3ceffbd95cf56a9d1ed4b4',
      messagingSenderId: '611007448413', // project_number
      projectId: 'todolist-c4680',
      storageBucket: 'todolist-c4680.appspot.com',
      authDomain: 'todolist-c4680.firebaseapp.com',
      databaseURL: 'https://todolist-c4680.firebaseio.com', // Jika Anda menggunakan Realtime Database
    );
  }
}
