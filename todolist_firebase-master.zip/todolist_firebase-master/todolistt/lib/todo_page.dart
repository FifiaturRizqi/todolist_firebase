import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class TodoPage extends StatefulWidget {
  @override
  _TodoPageState createState() => _TodoPageState();
}

class _TodoPageState extends State<TodoPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<QueryDocumentSnapshot> todos = [];

  @override
  void initState() {
    super.initState();
    _getTodos();
  }

  // Mendapatkan data todos dari Firestore
  void _getTodos() async {
    final snapshot = await _firestore.collection('Todos').get();
    setState(() {
      todos = snapshot.docs;
    });
  }

  // Fungsi untuk toggle status "isComplete"
  void _toggleComplete(String todoId, bool isComplete) {
    _firestore.collection('Todos').doc(todoId).update({
      'isComplete': !isComplete,
    });
  }

  // Fungsi untuk menampilkan dialog tambah todo baru
  void _showAddTodoDialog() {
    showDialog(
      context: context,
      builder: (context) {
        final TextEditingController titleController = TextEditingController();
        final TextEditingController descriptionController = TextEditingController();

        return AlertDialog(
          title: Text('Tambah Todo Baru'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: InputDecoration(labelText: 'Judul'),
              ),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(labelText: 'Deskripsi'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                String title = titleController.text;
                String description = descriptionController.text;

                if (title.isNotEmpty && description.isNotEmpty) {
                  // Menambahkan todo ke Firestore
                  _firestore.collection('Todos').add({
                    'tittle': title,
                    'description': description,
                    'isComplete': false,
                    'uid': 'userUid', // Gantilah dengan UID pengguna yang sudah login
                  });
                  Navigator.pop(context);
                  _getTodos(); // Update list todos setelah menambahkan data
                }
              },
              child: Text('Tambah'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('To-Do List'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: _showAddTodoDialog, // Menampilkan dialog untuk menambahkan todo
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar tetap ada di atas
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Cari Todo',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: todos.length,
              itemBuilder: (context, index) {
                final todo = todos[index];

                // Mengakses data dengan memeriksa tipe Map<String, dynamic>
                final data = todo.data() as Map<String, dynamic>?;

                if (data != null) {
                  final title = data.containsKey('tittle') ? data['tittle'] : 'Tidak ada judul';
                  final description = data.containsKey('description') ? data['description'] : 'Tidak ada deskripsi';
                  final isComplete = data.containsKey('isComplete') ? data['isComplete'] : false;
                  final todoId = todo.id;

                  return ListTile(
                    title: Text(title),
                    subtitle: Text(description),
                    leading: IconButton(
                      icon: Icon(
                        isComplete ? Icons.check_box : Icons.check_box_outline_blank,
                      ),
                      onPressed: () => _toggleComplete(todoId, isComplete),
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () {
                        _firestore.collection('Todos').doc(todoId).delete();
                        _getTodos(); // Update list todos setelah menghapus data
                      },
                    ),
                  );
                } else {
                  return ListTile(
                    title: Text('Data tidak valid'),
                    subtitle: Text('Tidak ada deskripsi'),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
