import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'view/login_page.dart'; // Halaman Login
import 'view/home_page.dart'; // Halaman Home
import 'services/firebase_options.dart'; // Impor konfigurasi Firebase

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform, // Gunakan konfigurasi Firebase
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Base ToDoList',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(), // Halaman Home sebagai halaman utama
    );
  }
}
